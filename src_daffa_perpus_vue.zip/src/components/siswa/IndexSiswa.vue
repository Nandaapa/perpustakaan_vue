<template>
    <div>
        <navbar-component></navbar-component>
        <sidebar-component></sidebar-component>
        <div class="content-wrapper">
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Data Siswa  </h1>
                        </div>
                    </div>
                </div>
            </div>

            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="card card-primary card-outline">
                                <div class="card-body">
                                    <router-link class="btn btn-info mb-2" to="siswa/CreateSiswa">
                                        <i class="fas fa-plus"></i> Tambah
                                    </router-link>
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th style="width: 10px">#</th>
                                                <th>Nama Lengkap</th>
                                                <th>Kelas</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr v-for="siswa in result" :key="siswa.id">
                                                <td>{{ siswa.id }}</td>
                                                <td>{{ siswa.nama_siswa }}</td>
                                                <td>{{ siswa.nama_kelas }}</td>
                                                <td>
                                                    <div class="btn-group">
                                                        <router-link class="btn btn-success"
                                                            :to="{ name: 'detailsiswa', params: { id: siswa.id } }">Detail</router-link>
                                                        <router-link class="btn btn-warning"
                                                            :to="{ name: 'editsiswa', params: { id: siswa.id } }">Edit</router-link>
                                                        <button type="button" @click="hapus(s.id)"
                                                            class="btn btn-danger">Hapus</button>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>

import Vue from 'vue';
import axios from 'axios';

Vue.use(axios);

import Navbars from "../template/UserNavbars.vue";
import Sidebars from "../template/UserSidebars.vue";

export default {
    data() {
        return {
            result: {}
        }
    },
    created() {
        this.userLoad();
    },
    methods: {
        userLoad() {
            var page = "http://localhost:8000/api/getsiswa";
            axios.get(page).then(
                ({ data }) => {
                    console.log(data);
                    this.result = data;
                }
            );

        },

        
    },
    components: {
            'navbar-component': Navbars,
            'sidebar-component': Sidebars,
        },
}
</script>
