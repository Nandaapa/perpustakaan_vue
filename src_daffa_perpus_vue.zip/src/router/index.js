

import Vue from 'vue'
import VueRouter from 'vue-router'

import Dashboard from '../views/DashboardView.vue'
import IndexSiswa from '../components/siswa/IndexSiswa.vue'
import CreateSiswa from '../components/siswa/CreateSiswa.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/user',
    name: 'Dashboard',
    component: Dashboard
  },
  {
    path: '/siswa',
    name: 'Siswa',
    component: IndexSiswa
  },
  {
    path : '/siswa/CreateSiswa',
    name : 'CreateSiswa',
    component : CreateSiswa
  }
  
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
